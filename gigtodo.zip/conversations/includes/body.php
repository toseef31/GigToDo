<!-- New Design -->

<div class="specfic col-md-9 p-0 <?=($lang_dir == "right" ? 'order-1 order-sm-2':'')?>">
	<div class="message-body" style="max-width: calc(100% - 0px)">
	<center id="selectConversation" class="mt-5 mt-sm-5">
		<img src="../images/chat.png" width="180" alt="">
		<h3 class="mt-3 empty-heading" style="font-weight:410;">Select a Conversation</h3>
		<p class="lead">Try selecting a conversation or searching for someone specific.</p>
	</center>
	
		<div id="msgHeader" class="bg-transparent inboxHeader2 d-none">
		</div>
		<div id="showSingle">
		</div>

	</div>
</div>
<!-- End New Design -->

<!-- <div class="specfic col-md-9 p-0 <?=($lang_dir == "right" ? 'order-1 order-sm-2':'')?>">
	<center id="selectConversation" class="mt-5 mt-sm-5">
		<img src="../images/chat.png" width="180" alt="">
		<h3 class="mt-3 empty-heading" style="font-weight:410;">Select a Conversation</h3>
		<p class="lead">Try selecting a conversation or searching for someone specific.</p>
	</center>
	<div id="msgHeader" class="card-header bg-transparent inboxHeader2 d-none">
	</div>
	<div id="showSingle" class="row">
	</div>
</div> -->