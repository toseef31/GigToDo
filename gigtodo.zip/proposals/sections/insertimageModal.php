<div id="insertimageModal" class="modal" role="dialog">
 
 <div class="modal-dialog modal-lg">
  
  <div class="modal-content">
      
      <div class="modal-header">
       
       Crop & Insert Image <button type="button" class="close" data-dismiss="modal">&times;</button>

      </div>

      <div class="modal-body">
      
        <div id="image_demo" style="width:100% !important;"></div>
       
      </div>

      <div class="modal-footer">

        <input type="hidden" name="img_name" value="">

        <input type="hidden" name="img_type" value="">

        <button class="btn btn-success crop_image">Crop Image</button>

        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

      </div>

    </div>
  
  </div>

</div>

<div id="wait"></div>